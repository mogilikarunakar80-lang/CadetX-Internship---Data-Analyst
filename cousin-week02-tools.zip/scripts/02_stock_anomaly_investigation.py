"""
Week 2 — Stock Ledger: A Closer Look
Heavy Supplier & Warehouse Analytics

Week 1's validation_report.md flagged the stock-ledger IN/OUT movement
sizes as "worth a look" but didn't dig into it. This script pulls together
the evidence you'd need to actually judge it: event counts (not just
average size), the actual growth trend for a sample product/branch, and
whether ADJUSTMENT entries correct for any drift.

This script deliberately stops short of a verdict. Look at the numbers and
the chart it produces, then decide for yourself: does this look like a
real (if unusual) business pattern, or does something about it look off?
Write your reasoning in your own words in docs/sprint_notes.md or wherever
your write-up lives.

Run: python3 02_stock_anomaly_investigation.py
"""
import pandas as pd
import numpy as np
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

BASE = os.path.dirname(__file__)
DOC_DIR = os.path.join(BASE, "..", "docs")
CHART_DIR = os.path.join(BASE, "..", "charts")
WEEK1_DATA = os.path.join(BASE, "..", "..", "cousin-week01", "data_clean")
os.makedirs(DOC_DIR, exist_ok=True)
os.makedirs(CHART_DIR, exist_ok=True)

sl = pd.read_csv(os.path.join(WEEK1_DATA, "stock_ledger.csv"), parse_dates=["movement_date"])

out = ["# Week 2 — Stock Ledger: A Closer Look\n\n",
       "Week 1 flagged the IN/OUT movement-size table as worth a second look. "
       "This pulls together three pieces of evidence — read them together "
       "before deciding what's going on.\n\n"]

# ---- 1. Event counts, not just average size ----
mv = sl.groupby("movement_type").agg(n_events=("quantity", "count"), mean_qty=("quantity", "mean"),
                                       total_qty=("quantity", "sum")).round(1)
out.append("## 1. IN vs OUT: count AND size\n\n")
out.append(mv.to_markdown() + "\n\n")

in_events, out_events = mv.loc["IN", "n_events"], mv.loc["OUT", "n_events"]
in_total, out_total = mv.loc["IN", "total_qty"], mv.loc["OUT", "total_qty"]
out.append(f"IN events: **{in_events:,.0f}**, OUT events: **{out_events:,.0f}**. "
           f"IN total volume: **{in_total:,.0f} units**, OUT total volume: **{out_total:,.0f} units** "
           f"(difference: **{in_total - out_total:,.0f} units**).\n\n"
           f"Ask yourself: if this were a normal bulk-replenishment pattern (a few big restocks feeding "
           f"many small day-to-day sales), what would you expect the relationship between event *counts* "
           f"to look like, versus what you see here?\n\n")

# ---- 2. Trend fit: is growth linear, and does it revert? ----
sample = sl[(sl.product_id == "P001") & (sl.branch_id == "DEL001")].sort_values("movement_date").reset_index(drop=True)
sample["day_num"] = (sample["movement_date"] - sample["movement_date"].min()).dt.days
slope, intercept = np.polyfit(sample["day_num"], sample["running_balance"], 1)
out.append("## 2. Growth trend (P001 @ DEL001, as a representative sample)\n\n")
out.append(f"Linear fit to `running_balance` over time: slope = **{slope:.2f} units/day**. "
           f"Look at the chart below: does the balance oscillate around some stable operating level "
           f"(what you'd expect in a real warehouse), or does it move in one direction fairly "
           f"consistently?\n\n")

plt.figure(figsize=(9, 4.5))
plt.plot(sample["movement_date"], sample["running_balance"], linewidth=1.2, color="#2f6e5c")
plt.title("running_balance over time -- P001 @ DEL001")
plt.xlabel("date")
plt.ylabel("running_balance (units)")
plt.tight_layout()
plt.savefig(os.path.join(CHART_DIR, "stock_trend_p001_del001.png"), dpi=130)
plt.close()
out.append("See `charts/stock_trend_p001_del001.png`.\n\n")

# ---- 3. Do ADJUSTMENT movements correct for the IN/OUT gap? ----
adj = sl[sl.movement_type == "ADJUSTMENT"]
out.append("## 3. Do ADJUSTMENT entries correct for this?\n\n")
out.append(f"{len(adj):,} ADJUSTMENT rows exist, averaging {adj['quantity'].mean():.1f} units each "
           f"({adj['quantity'].sum():,} total). Compare that total to the IN/OUT gap from section 1 — "
           f"is it large enough to explain the difference, or not?\n\n")

out.append("## Over to you\n\nBased on sections 1-3: is this a real warehousing pattern, or does "
            "something about the data look like an artifact/bug to you? Justify your answer with the "
            "specific numbers above — don't just assert a conclusion.\n")

with open(os.path.join(DOC_DIR, "stock_ledger_closer_look.md"), "w") as f:
    f.writelines(out)

print("Investigation written to docs/stock_ledger_closer_look.md")
print(f"IN events: {in_events:,.0f}  OUT events: {out_events:,.0f}")
print(f"IN total: {in_total:,.0f}  OUT total: {out_total:,.0f}  gap: {in_total - out_total:,.0f}")
print(f"Trend slope (P001@DEL001): {slope:.2f} units/day")
