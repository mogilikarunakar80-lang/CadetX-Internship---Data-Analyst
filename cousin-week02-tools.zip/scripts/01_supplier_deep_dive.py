"""
Week 2 — Supplier Deep Dive
Heavy Supplier & Warehouse Analytics

Week 1's KPI script already gave you a first look at supplier concentration
(top-5 share of PO value) and lead-time gaps. This script goes one level
deeper on two specific questions:

  1. Are the suppliers you depend on most ALSO your least reliable ones?
     (concentration risk stacked on top of reliability risk)
  2. Which products only have ONE supplier feeding them? (single-source risk
     — if that one supplier has a problem, that product's supply stops
     entirely, with no backup)

This script only computes the numbers and saves them. It does NOT tell you
what to conclude — read docs/supplier_deep_dive.md once it's generated and
write your own interpretation (which suppliers worry you and why, whether
single-sourcing is actually a problem here or not) in your own words.

Run: python3 01_supplier_deep_dive.py
"""
import pandas as pd
import os

BASE = os.path.dirname(__file__)
DATA = os.path.join(BASE, "..", "data_clean")
DOC_DIR = os.path.join(BASE, "..", "docs")
WEEK1_DATA = os.path.join(BASE, "..", "..", "cousin-week01", "data_clean")
os.makedirs(DATA, exist_ok=True)
os.makedirs(DOC_DIR, exist_ok=True)

suppliers = pd.read_csv(os.path.join(WEEK1_DATA, "suppliers.csv"))
po_header = pd.read_csv(os.path.join(WEEK1_DATA, "purchase_orders_header.csv"), parse_dates=["order_date"])
po_lines = pd.read_csv(os.path.join(WEEK1_DATA, "purchase_orders_lines.csv"))
products = pd.read_csv(os.path.join(WEEK1_DATA, "products.csv"))

out = ["# Week 2 — Supplier Deep Dive\n\n",
       "Numbers only below — no conclusions written in. Read each section and "
       "add your own notes on what it means for the business.\n\n"]

# ---- 1. Spend concentration + reliability overlap ----
by_supplier = (po_header.merge(suppliers, on="supplier_id")
               .groupby(["supplier_id", "supplier_name", "supplier_type", "reliability_score", "lead_time_days"])
               ["grand_total"].sum().sort_values(ascending=False))
total_value = by_supplier.sum()
by_supplier_df = by_supplier.reset_index()
by_supplier_df["share_pct"] = (by_supplier_df["grand_total"] / total_value * 100).round(1)
by_supplier_df["dependency_rank"] = by_supplier_df["share_pct"].rank(ascending=False)
by_supplier_df.to_csv(os.path.join(DATA, "supplier_contribution.csv"), index=False)

out.append("## 1. Spend concentration vs. reliability\n\n")
out.append(by_supplier_df.to_markdown(index=False) + "\n\n")
out.append(f"Reliability scores in this dataset range {suppliers['reliability_score'].min()}–"
           f"{suppliers['reliability_score'].max()}. Pick your own cutoff for 'low reliability' and "
           f"'high dependency' and see which supplier(s), if any, land in both buckets.\n\n")

# ---- 2. Product-level single-source risk ----
prod_supplier = (po_lines.merge(po_header[["po_id", "supplier_id"]], on="po_id")
                  .groupby(["product_id", "supplier_id"])["line_total"].sum().reset_index())
n_suppliers_per_product = prod_supplier.groupby("product_id")["supplier_id"].nunique().rename("n_suppliers")
top_share_per_product = (prod_supplier.groupby("product_id")["line_total"]
                          .apply(lambda s: s.max() / s.sum() * 100).round(1).rename("top_supplier_share_pct"))
dependency = pd.concat([n_suppliers_per_product, top_share_per_product], axis=1).merge(
    products[["product_id", "product_name"]], left_index=True, right_on="product_id")
dependency.to_csv(os.path.join(DATA, "product_supplier_dependency.csv"), index=False)

single_sourced = dependency[dependency["n_suppliers"] == 1].sort_values("product_name")
out.append(f"## 2. Product-level supplier dependency\n\n{len(single_sourced)} of {len(dependency)} "
           f"products are sourced from exactly one supplier. Full table saved to "
           f"`data_clean/product_supplier_dependency.csv` — worth checking whether any of those "
           f"single-sourced products are also high-volume or high-criticality ones (see "
           f"`products.csv`'s `criticality_level` column).\n\n")

# ---- 3. Lead time: stated vs actual, per supplier ----
received = po_header.dropna(subset=["received_date"]).merge(suppliers, on="supplier_id")
received["received_date"] = pd.to_datetime(received["received_date"])
received["actual_lead_time"] = (received["received_date"] - received["order_date"]).dt.days
lt_by_supplier = received.groupby(["supplier_name", "lead_time_days"])["actual_lead_time"].agg(["median", "count"]).reset_index()
lt_by_supplier["gap_days"] = (lt_by_supplier["median"] - lt_by_supplier["lead_time_days"]).round(1)
lt_by_supplier = lt_by_supplier.sort_values("gap_days", ascending=False)
lt_by_supplier.to_csv(os.path.join(DATA, "supplier_lead_time_gap.csv"), index=False)

out.append("## 3. Lead time: stated vs. actual, by supplier\n\n")
out.append("Positive gap = supplier runs slower than what they quote.\n\n")
out.append(lt_by_supplier.rename(columns={"lead_time_days": "stated_days", "median": "actual_median_days"}).to_markdown(index=False) + "\n\n")

out.append("## Over to you\n\nWrite 3-4 sentences: which supplier(s) would you flag as a risk and why "
            "(concentration, reliability, lead time, or some combination)? Is single-sourcing actually "
            "a problem for this business given what you found in section 2?\n")

with open(os.path.join(DOC_DIR, "supplier_deep_dive.md"), "w") as f:
    f.writelines(out)

print("Supplier deep dive written to docs/supplier_deep_dive.md")
print(f"Single-sourced products: {len(single_sourced)}/{len(dependency)}")
