# Week 2 — Feature Engineering Notes

Feature table: `data_clean/features_week2.csv`, one row per product-branch (30 products x 6 branches = 180 rows).

| feature | how it's built | why it might matter |
|---|---|---|
| avg_monthly_units | mean of monthly `sales_orders_lines.quantity` | baseline demand level |
| demand_cv | std / mean of monthly units | one way to measure volatility -- check the distribution below and decide if the thresholds used actually split products usefully |
| demand_volatility_tier | cv bucketed: stable / moderate / volatile (0.3 / 0.6 cutoffs) | a starting point only -- these cutoffs were picked arbitrarily, not tuned to this data |
| days_of_safety_stock | safety_stock / avg_daily_units | uses `safety_stock`, not `current_stock` -- decide for yourself in your write-up whether that's the right call given what 02_stock_anomaly_investigation.py showed |
| reorder_covers_lead_time | reorder_level/avg_daily_units >= lead_time_days | flags SKUs where the reorder trigger may fire too late relative to supplier lead time |

## Distribution of volatility tiers

| demand_volatility_tier   |   count |
|:-------------------------|--------:|
| moderate                 |     180 |

If one tier dominates almost every row, that's a sign the 0.3/0.6 cutoffs above aren't actually splitting your products usefully -- worth trying different cutoffs and seeing if that changes.

## Products where the reorder point may not cover lead time

77 of 180 product-branch combos flagged.

## Over to you

Pick 2-3 features from this table and write a few sentences on what each one would let the business actually do differently (e.g. plan stock ahead of time, flag a risky SKU). What would you add to this table if you had another data source available?
