# Week 2 — Supplier Deep Dive

Numbers only below — no conclusions written in. Read each section and add your own notes on what it means for the business.

## 1. Spend concentration vs. reliability

| supplier_id   | supplier_name                   | supplier_type   |   reliability_score |   lead_time_days |   grand_total |   share_pct |   dependency_rank |
|:--------------|:--------------------------------|:----------------|--------------------:|-----------------:|--------------:|------------:|------------------:|
| SUP0005       | Tianjin OEM Supplies            | OEM             |                   3 |               28 |   5.70212e+10 |        12.9 |               1   |
| SUP0001       | Shenzhen OEM Supplies           | OEM             |                   5 |               19 |   5.5643e+10  |        12.6 |               3   |
| SUP0003       | Shanghai Distributor Supplies   | Distributor     |                   4 |               16 |   5.56398e+10 |        12.6 |               3   |
| SUP0007       | Suzhou Local Vendor Supplies    | Local Vendor    |                   5 |               12 |   5.55977e+10 |        12.6 |               3   |
| SUP0008       | Hangzhou OEM Supplies           | OEM             |                   4 |               26 |   5.53549e+10 |        12.5 |               5.5 |
| SUP0006       | Qingdao Distributor Supplies    | Distributor     |                   3 |               10 |   5.50936e+10 |        12.5 |               5.5 |
| SUP0004       | Ningbo Distributor Supplies     | Distributor     |                   3 |               18 |   5.40602e+10 |        12.2 |               7   |
| SUP0002       | Guangzhou Local Vendor Supplies | Local Vendor    |                   5 |               10 |   5.3276e+10  |        12.1 |               8   |

Reliability scores in this dataset range 3–5. Pick your own cutoff for 'low reliability' and 'high dependency' and see which supplier(s), if any, land in both buckets.

## 2. Product-level supplier dependency

0 of 30 products are sourced from exactly one supplier. Full table saved to `data_clean/product_supplier_dependency.csv` — worth checking whether any of those single-sourced products are also high-volume or high-criticality ones (see `products.csv`'s `criticality_level` column).

## 3. Lead time: stated vs. actual, by supplier

Positive gap = supplier runs slower than what they quote.

| supplier_name                   |   stated_days |   actual_median_days |   count |   gap_days |
|:--------------------------------|--------------:|---------------------:|--------:|-----------:|
| Guangzhou Local Vendor Supplies |            10 |                   10 |    2635 |          0 |
| Hangzhou OEM Supplies           |            26 |                   26 |    2722 |          0 |
| Ningbo Distributor Supplies     |            18 |                   18 |    2664 |          0 |
| Qingdao Distributor Supplies    |            10 |                   10 |    2752 |          0 |
| Shanghai Distributor Supplies   |            16 |                   16 |    2723 |          0 |
| Shenzhen OEM Supplies           |            19 |                   19 |    2653 |          0 |
| Suzhou Local Vendor Supplies    |            12 |                   12 |    2727 |          0 |
| Tianjin OEM Supplies            |            28 |                   28 |    2754 |          0 |

## Over to you

Write 3-4 sentences: which supplier(s) would you flag as a risk and why (concentration, reliability, lead time, or some combination)? Is single-sourcing actually a problem for this business given what you found in section 2?
