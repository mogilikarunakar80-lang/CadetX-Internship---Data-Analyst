# Week 2 — Stock Ledger: A Closer Look

Week 1 flagged the IN/OUT movement-size table as worth a second look. This pulls together three pieces of evidence — read them together before deciding what's going on.

## 1. IN vs OUT: count AND size

| movement_type   |   n_events |   mean_qty |       total_qty |
|:----------------|-----------:|-----------:|----------------:|
| ADJUSTMENT      |       2454 |       27.3 | 66990           |
| IN              |     127611 |      159.8 |     2.03978e+07 |
| OUT             |     107165 |       10.5 |     1.12483e+06 |

IN events: **127,611**, OUT events: **107,165**. IN total volume: **20,397,795 units**, OUT total volume: **1,124,832 units** (difference: **19,272,963 units**).

Ask yourself: if this were a normal bulk-replenishment pattern (a few big restocks feeding many small day-to-day sales), what would you expect the relationship between event *counts* to look like, versus what you see here?

## 2. Growth trend (P001 @ DEL001, as a representative sample)

Linear fit to `running_balance` over time: slope = **52.70 units/day**. Look at the chart below: does the balance oscillate around some stable operating level (what you'd expect in a real warehouse), or does it move in one direction fairly consistently?

See `charts/stock_trend_p001_del001.png`.

## 3. Do ADJUSTMENT entries correct for this?

2,454 ADJUSTMENT rows exist, averaging 27.3 units each (66,990 total). Compare that total to the IN/OUT gap from section 1 — is it large enough to explain the difference, or not?

## Over to you

Based on sections 1-3: is this a real warehousing pattern, or does something about the data look like an artifact/bug to you? Justify your answer with the specific numbers above — don't just assert a conclusion.
